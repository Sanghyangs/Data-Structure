#include <stdlib.h> // malloc, atoi, rand
#include <stdio.h>
#include <ctype.h> // isdigit
#include <assert.h> // assert
#include <time.h> // time

////////////////////////////////////////////////////////////////////////////////
// TREE type definition
typedef struct node
{
	int		data;
	struct node	*left;
	struct node	*right;
} NODE;

typedef struct
{
	NODE	*root;
} TREE;

////////////////////////////////////////////////////////////////////////////////
// Prototype declarations

/* Allocates dynamic memory for a tree head node and returns its address to caller
	return	head node pointer
		NULL if overflow
*/
TREE *BST_Create(void) {
	TREE *tree = calloc(1, sizeof(TREE));
	return tree;
}

/* Deletes all data in tree and recycles memory
	return	NULL head pointer
*/
TREE *BST_Destroy( TREE *pTree);
static void _destroy(NODE *root)
{
	if (root == NULL) {
		return;
	}
	if (root->left == NULL && root->right == NULL) {
		free(root);
		return;
	}
	_destroy(root->left);
	_destroy(root->right);
}

/* Inserts new data into the tree
	return	1 success
		0 overflow
*/
int BST_Insert(TREE *pTree, int data);

static NODE *_makeNode(int data) {
	NODE *node = calloc(1, sizeof(NODE));
	if (node != NULL) {
		node->data = data;
	}

	return node;
}

/* Deletes a node with dltKey from the tree
	return	1 success
		0 not found
*/
int BST_Delete( TREE *pTree, int dltKey);

/* internal function
	success is 1 if deleted; 0 if not
	return	pointer to root
*/
NODE *_delete(NODE *root, int dltKey, int *success)
{
	*success = 0;

	if (root == NULL) {
		return root;
	}

	if (dltKey < root->data) {
		root->left = _delete(root->left, dltKey, success);
	}
	else if (dltKey > root->data) {
		root->right = _delete(root->right, dltKey, success);
	}
	else
	{
		if (root->left == NULL)
		{
			NODE *temp = root->right;
			free(root);
			*success = 1;
			return temp;
		}
		else if (root->right == NULL)
		{
			NODE *temp = root->left;
			free(root);
			*success = 1;
			return temp;
		}

		NODE *temp = root->right;

		while (temp && temp->left != NULL)
			temp = temp->left;

		root->data = temp->data;

		root->right = _delete(root->right, temp->data, success);
	}

	return root;
}

/* Retrieve tree for the node containing the requested key
	return	address of data of the node containing the key
		NULL not found
*/
int *BST_Retrieve( TREE *pTree, int key);

/* internal function
	Retrieve node containing the requested key
	return	address of the node containing the key
		NULL not found
*/
NODE *_retrieve( NODE *root, int key);

/* prints tree using inorder traversal
*/
void BST_Traverse( TREE *pTree);
static void _traverse(NODE *root)
{
	if (root == NULL)
		return;

	_traverse(root->left);

	printf("%d ", root->data);

	_traverse(root->right);
}

/* Print tree using inorder right-to-left traversal
*/
void printTree( TREE *pTree);
/* internal traversal function
*/
static void _infix_print(NODE *root, int level)
{
	int current = level;
	if (root->right != NULL) {
		_infix_print(root->right, current + 1);
	}
	for (int index = 0; index < level; index++) {
		printf("\t");
	}
	printf("%5d\n", root->data);

	if (root->left != NULL) {
		_infix_print(root->left, current + 1);
	}
}


NODE *_insertNode(NODE *root, int data)
{
	if (root == NULL) {
		NODE *newnode = _makeNode(data);
		if (newnode != NULL) {
			root = newnode;
		}
		return newnode;
	}

	if (root->data > data) {
		root->left = _insertNode(root->left, data);
	}
	else {
		root->right = _insertNode(root->right, data);
	}

	return root;
}

int BST_Insert(TREE *pTree, int data)
{
	if (pTree == NULL) {
		return 0;
	}

	if (pTree->root == NULL) {
		NODE *newnode = _makeNode(data);
		if (newnode == NULL) {
			return 0;
		}

		pTree->root = newnode;
		return 1;
	}

	_insertNode(pTree->root, data);
}

void printTree(TREE *pTree)
{
	if (pTree == NULL) {
		return;
	}

	if (pTree->root != NULL) {
		_infix_print(pTree->root, 0);
	}

	return;
}

void BST_Traverse(TREE *pTree)
{
	_traverse(pTree->root);
}

int BST_Delete(TREE *pTree, int dltKey)
{
	int success;
	pTree->root = _delete(pTree->root, dltKey, &success);
	return success;
}

TREE *BST_Destroy(TREE *pTree)
{
	_destroy(pTree->root);
	free(pTree);
}

////////////////////////////////////////////////////////////////////////////////
int main( int argc, char **argv)
{
	TREE *tree;
	int data;
	
	// creates a null tree
	tree = BST_Create();
	
	if (!tree)
	{
		printf( "Cannot create tree\n");
		return 100;
	}

	fprintf( stdout, "Inserting: ");
	
	srand( time(NULL));
	for (int i = 1; i < 20; i++)
	{
		data = rand() % 100 + 1; // 1 ~ 100 random number
		
		fprintf( stdout, "%d ", data);
		
		// insert funtion call
		BST_Insert( tree, data);
 	}
	fprintf( stdout, "\n");

	printTree(tree);	// TODO: test

	// inorder traversal
	fprintf( stdout, "Inorder traversal: ");
	BST_Traverse( tree);
	fprintf( stdout, "\n");
	
	// print tree with right-to-left infix traversal
	fprintf( stdout, "Tree representation:\n");
	printTree(tree);
	
	int ret;
	do
	{
		fprintf( stdout, "Input a number to delete: "); 
		int num;
		ret = scanf( "%d", &num);
		if (ret != 1) break;
		
		ret = BST_Delete( tree, num);
		if (!ret) fprintf( stdout, "%d not found\n", num);
		
		// print tree with right-to-left infix traversal
		fprintf( stdout, "Tree representation:\n");
		printTree(tree);
		
	} while(1);
	
	BST_Destroy( tree);

	return 0;
}
