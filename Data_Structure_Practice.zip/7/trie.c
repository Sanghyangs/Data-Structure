#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> // isupper, tolower

#define MAX_DEGREE	27 // 'a' ~ 'z' and EOW
#define EOW			'$' // end of word

// used in the following functions: trieInsert, trieSearch, triePrefixList
#define getIndex(x)		(((x) == EOW) ? MAX_DEGREE-1 : ((x) - 'a'))

// TRIE type definition
typedef struct trieNode {
	char 			*entry;
	struct trieNode	*subtrees[MAX_DEGREE];
} TRIE;

TRIE * trieCreateNode(void);
void trieDestroy(TRIE *root);
int trieInsert(TRIE *root, char *str);
int trieSearch(TRIE *root, char *str);
void trieList(TRIE *root);
void triePrefixList(TRIE *root, char *str);
int make_permuterms(char *str, char *permuterms[]);
void clear_permuterms(char *permuterms[], int size);
void trieSearchWildcard(TRIE *root, char *str);

////////////////////////////////////////////////////////////////////////////////
// Prototype declarations

/* Allocates dynamic memory for a trie node and returns its address to caller
	return	node pointer
			NULL if overflow
*/
TRIE *trieCreateNode(void) {
	TRIE *trie = (TRIE*)calloc(1, sizeof(TRIE));
	return trie;
}

/* Deletes all data in trie and recycles memory
*/
void trieDestroy(TRIE *root) {
	if (root == NULL) {
		return;
	}
	/***
	for(int i = 0; i < MAX_DEGREE; i++) {
		if (root->subtrees[i] != NULL) {
		}
	}
	***/
	for (int i = 0; i < MAX_DEGREE; i++) {
		trieDestroy(root->subtrees[i]);
	}
}

/* Inserts new entry into the trie
	return	1 success
			0 failure
*/
// ����! ��Ʈ���� �ߺ� �������� �ʵ��� üũ�ؾ� ��
// ��ҹ��ڸ� �ҹ��ڷ� �����Ͽ� ����
// ������ �� ���ڸ� �����ϴ� ���ڿ��� �������� ����
int trieInsert(TRIE *root, char *str)
{
	for (int i = 0; i < strlen(str); i++) {
		if (isalpha(str[i]) == 0) {
			if (str[i] != '$')
				return 0;
		}
	}
	for (int i = 0; i < strlen(str); i++) {
		if (str[i] == '$') {
			continue;
		}
		if (isupper(str[i])!=0) {
			str[i] = tolower(str[i]);
		}
	}

	TRIE *current = root;
	int position;
	char ch;
	for (int i = 0; i < strlen(str); i++)
	{
		ch = str[i];
		position = getIndex(ch);	// ch - 'a';
		if (current->subtrees[position] == NULL) {
			current->subtrees[position] = trieCreateNode();
		}

		current = current->subtrees[position];
	}

	current->entry = "$";	// EOW;
	return 1;
}

/* Retrieve trie for the requested key
	return	1 key found
			0 key not found
*/
int trieSearch(TRIE *root, char *str) {	
	for (int i = 0; i < strlen(str); i++) {
		if (isalpha(str[i]) == 0)
			return 0;
	}
	for (int i = 0; i < strlen(str); i++) {
		if (isupper(str[i]) != 0) {
			str[i] = tolower(str[i]);
		}
	}

	TRIE *current = root;
	int position;
	char ch;
	for (int i = 0; i < strlen(str); i++)
	{
		ch = str[i];
		position = ch - 'a';
		if (current->subtrees[position] == NULL) {
			return 0;
		}

		current = current->subtrees[position];
	}

	if (current->entry == "$") {
		return 1;
	}
	return 0;
}

/* prints all entries in trie using preorder traversal
*/
void trieList(TRIE *root) {
	while (root->entry != "$") {//���ڿ��� ������ �ʾ���������
		for (int i = 0; i < MAX_DEGREE; i++) {
			char ch = 'a' + i;
			printf("%c", ch);
			if (root->subtrees[i] != NULL) {
				trieList(root->subtrees[i]);
			}
		}
	}
	printf("\n");
}

/* prints all entries starting with str (as prefix) in trie
   ex) "abb" -> "abbas", "abbasid", "abbess", ...
	using trieList function
*/
void triePrefixList( TRIE *root, char *str);

/* makes permuterms for given str
	ex) "abc" -> "abc$", "bc$a", "c$ab", "$abc"
	return	number of permuterms
*/
int make_permuterms(char *str, char *permuterms[])
{
	int len = strlen(str);
	int len2 = len + 1;
	char str2[100], str3[100];
	char temp;

	memset((char *)&str2[0], 0x00, sizeof(str2));
	sprintf(str2, "%s$", str);

	for (int i = 0; i < len2; i++) {
		permuterms[i] = strdup(str2);

		temp = str2[i];
		str2[i] = str2[(i + 1) % len2];
		str2[(i + 1) % len2] = str2[(i + 2) % len2];
		str2[(i + 2) % len2] = str2[(i + 3) % len2];
		str2[(i + 3) % len2] = temp;
	}

	return (len + 1);
}

/* recycles memory for permuterms
*/
void clear_permuterms(char *permuterms[], int size) {
	for (int i = 0; i < size; i++) {
		free(permuterms[i]);
	}
}

/* wildcard search
	ex) "ab*", "*ab", "a*b", "*ab*"
	using triePrefixList function
*/
void trieSearchWildcard( TRIE *root, char *str);

int main(int argc, char **argv)
{
	TRIE *trie;
	TRIE *permute_trie;
	int ret;
	char str[100];
	FILE *fp;
	char *permuterms[100];
	int num_p;
	
	if (argc != 2)
	{
		fprintf( stderr, "Usage: %s FILE\n", argv[0]);
		return 1;
	}
	
	fp = fopen( argv[1], "rt");
	if (fp == NULL)
	{
		fprintf( stderr, "File open error: %s\n", argv[1]);
		return 1;
	}
	
	trie = trieCreateNode(); // original trie
	permute_trie = trieCreateNode(); // trie for permuterm index
	
	printf( "Inserting to trie...\t");
	while (fscanf( fp, "%s", str) == 1) // words file
	{	
		ret = trieInsert( trie, str);
		
		if (ret)
		{
			num_p = make_permuterms( str, permuterms);
			
			for (int i = 0; i < num_p; i++)
				trieInsert( permute_trie, permuterms[i]);
			
			clear_permuterms( permuterms, num_p);
		}
	}
	
	printf( "[done]\n"); // Inserting to trie

	fclose( fp);
	
	printf( "\nQuery: ");
	while (fscanf( stdin, "%s", str) == 1)
	{
		if (strchr( str, '*')) // wildcard search term
		{
//			trieSearchWildcard( permute_trie, str);
		}
		else // search term
		{
			ret = trieSearch( trie, str);
			printf( "[%s]%s found!\n", str, ret ? "": " not");
		}
		printf( "\nQuery: ");
	}

//	trieDestroy( trie);
//	trieDestroy( permute_trie);
	
	return 0;
}