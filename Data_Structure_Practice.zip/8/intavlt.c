#include <stdlib.h> // malloc, rand
#include <stdio.h>
#include <time.h> // time

#define MAX_ELEM 20
#define max(x, y)	(((x) > (y)) ? (x) : (y))

////////////////////////////////////////////////////////////////////////////////
// AVL_TREE type definition
typedef struct node
{
	int			data;
	struct node	*left;
	struct node	*right;
	int			height;
} NODE;

typedef struct
{
	NODE	*root;
	int		count;  // number of nodes
} AVL_TREE;

////////////////////////////////////////////////////////////////////////////////
// Prototype declarations

static void _destroy(NODE *root);
static NODE *_insert(NODE *root, NODE *newPtr);
static NODE *_makeNode(int data);
static void _traverse(NODE *root);
static NODE *_retrieve(NODE *root, int key);
static void _infix_print(NODE *root, int level);
static NODE *rotateLeft(NODE *root);
static NODE *rotateRight(NODE *root);
static int getHeight(NODE *root);

/* Allocates dynamic memory for a AVL_TREE head node and returns its address to caller
	return	head node pointer
			NULL if overflow
*/
AVL_TREE *AVL_Create(void) {
	AVL_TREE* avlt = calloc(1, sizeof(AVL_TREE));
	return avlt;
}

/* Deletes all data in tree and recycles memory
	return	NULL head pointer
*/
AVL_TREE *AVL_Destroy(AVL_TREE *pTree) {
	if (pTree != NULL) {
		_destroy(pTree->root);
		free(pTree);
	}
	return NULL;
}
static void _destroy(NODE *root) {
	if (root == NULL) {
		return;
	}

	if (root->left != NULL) _destroy(root->left);
	if (root->right != NULL) _destroy(root->right);
	free(root);
}

/* Inserts new data into the tree
	return	1 success
			0 overflow
*/
int AVL_Insert(AVL_TREE *pTree, int data) {
	NODE* newnode = _makeNode(data);
	if (newnode == NULL)
		return 0;

	if (pTree->root == NULL) {
		pTree->root=newnode;
		pTree->count = 1;
		return 1;
	}

	_insert(pTree->root, newnode);
	pTree->count++;
}

/* internal function
	This function uses recursion to insert the new data into a leaf node
	return	pointer to new root
*/
static NODE *_insert(NODE *root, NODE *newPtr) {
	if (root == NULL) {
		return newPtr;
	}
	if (root->data < newPtr->data) {
		root->right = _insert(root->right, newPtr);
	}
	else if (root->data > newPtr->data) {
		root->left = _insert(root->left, newPtr);
	}
	else {
		root->right = _insert(root->right, newPtr);
	}

	int h1 = getHeight(root->left);
	int h2 = getHeight(root->right);
	root->height = max(h1, h2) + 1;

	int diff = h1 - h2;
	if ((diff > 1) && (newPtr->data < root->left->data)) {
		return rotateRight(root);

	}
	if ((diff > 1) && (newPtr->data > root->left->data)) {
		root->left = rotateLeft(root->left);
		return rotateRight(root);
	}
	if ((diff < -1) && (newPtr->data > root->right->data)) {
		return rotateLeft(root);
	}
	if ((diff < -1) && (newPtr->data < root->right->data)) {
		root->right = rotateRight(root->right);
		return rotateLeft(root);
	}

	return root;
}

static NODE *_makeNode(int data) {
	NODE *node = calloc(1, sizeof(NODE));
	if (node != NULL) {
		node->data = data;
		node->height = 1;
	}

	return node;
}

/* Retrieve tree for the node containing the requested key
	return	address of data of the node containing the key
			NULL not found
*/
int *AVL_Retrieve(AVL_TREE *pTree, int key) {
	if (pTree==NULL) {
		return NULL;
	}
	NODE *node = _retrieve(pTree->root, key);
	if (node == NULL) {
		return NULL;
	}
	return &(node->data);
}

/* internal function
	Retrieve node containing the requested key
	return	address of the node containing the key
			NULL not found
*/
static NODE *_retrieve(NODE *root, int key) {
	NODE* curnode = root;
	if (root == NULL) {
		return NULL;
	}
	while (curnode->data != key) {
		if (key < curnode->data) {
			curnode = _retrieve(curnode->left, key);
		}
		else if (key > curnode->data) {
			curnode = _retrieve(curnode->right, key);
		}
	}
	return curnode;
}


/* Prints tree using inorder traversal
*/
void AVL_Traverse(AVL_TREE *pTree) {
	_traverse(pTree->root);
}

static void _traverse(NODE *root) {
	if (root == NULL)
		return;

	_traverse(root->left);

	printf("%d ", root->data);

	_traverse(root->right);
}

/* Prints tree using inorder right-to-left traversal
*/
void printTree(AVL_TREE *pTree) {
	if (pTree == NULL) {
		return;
	}

	if (pTree->root != NULL) {
		_infix_print(pTree->root, 0);
	}

	return;
}
/* internal traversal function
*/
static void _infix_print(NODE *root, int level) {
	int current = level;
	if (root->right != NULL) {
		_infix_print(root->right, current + 1);
	}
	for (int index = 0; index < level; index++) {
		printf("\t");
	}
	printf("%d\n", root->data);

	if (root->left != NULL) {
		_infix_print(root->left, current + 1);
	}
}

/* internal function
	return	height of the (sub)tree from the node (root)
*/
static int getHeight(NODE *root) {
	if (root == NULL) {
		return 0;
	}
	
	return root->height;
}

/* internal function
	Exchanges pointers to rotate the tree to the right
	updates heights of the nodes
	return	new root
*/
static NODE *rotateRight(NODE *root)
{
	NODE *x = root->left;
	NODE *T2 = root->right;

	x->right = root;
	root->left = T2;

	int h1 = getHeight(root->left);
	int h2 = getHeight(root->right);
	root->height = max(h1, h2) + 1;

	h1 = getHeight(x->left);
	h2 = getHeight(x->right);
	x->height = max(h1, h2) + 1;

	return x;
}

/* internal function
	Exchanges pointers to rotate the tree to the left
	updates heights of the nodes
	return	new root
*/
static NODE *rotateLeft(NODE *root)
{
	NODE *y = root->right;
	NODE *T2 = root->left;
	
	y->left = root;
	root->right = T2;

	int h1 = getHeight(root->left);
	int h2 = getHeight(root->right);
	root->height = max(h1, h2) + 1;

	h1 = getHeight(y->left);
	h2 = getHeight(root->right);
	y->height = max(h1, h2) + 1;

	return y;
}

////////////////////////////////////////////////////////////////////////////////
int main( int argc, char **argv)
{
	AVL_TREE *tree;
	int data;
	
	// creates a null tree
	tree = AVL_Create();
	
	if (!tree)
	{
		printf( "Cannot create tree\n");
		return 100;
	}

	fprintf( stdout, "Inserting: ");
	
	srand( time(NULL));
	for (int i = 0; i < MAX_ELEM; i++)
	{
		data = rand() % (MAX_ELEM * 3) + 1; // random number
		 //data = i+1; // sequential number
		
		fprintf( stdout, "%d ", data);

		// insert function call
		AVL_Insert( tree, data);
	}
	fprintf( stdout, "\n");

	// inorder traversal
	fprintf( stdout, "Inorder traversal: ");
	AVL_Traverse( tree);
	fprintf( stdout, "\n");
	
	// print tree with right-to-left infix traversal
	fprintf( stdout, "Tree representation:\n");
	printTree(tree);
	
	fprintf( stdout, "Height of tree: %d\n", tree->root->height);
	fprintf( stdout, "# of nodes: %d\n", tree->count);
	
	AVL_Destroy( tree);

	return 0;
}