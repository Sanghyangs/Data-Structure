#include <stdio.h>
#include <stdlib.h> // malloc, rand
#include <time.h> // time
#include <assert.h>

#define MAX_ELEM	20

typedef struct
{
	int *heapArr;
	int	last;
	int	capacity;
} HEAP;

HEAP *heapCreate(int capacity) {
	HEAP *heap = (HEAP*)calloc(1, sizeof(HEAP));
	heap->heapArr = calloc(capacity + 1, sizeof(int));
	return heap;
}

void heapDestroy(HEAP *heap) {
	free(heap->heapArr);
	free(heap);
}

int heapInsert(HEAP *heap, int data);

static void _reheapUp(HEAP *heap, int index)
{
	int temp = heap->heapArr[index];
	while (index > 0 && temp > heap->heapArr[(index - 1) / 2]) {
		heap->heapArr[index] = heap->heapArr[(index - 1) / 2];
		index = (index - 1) / 2;
	}
	heap->heapArr[index] = temp;
}

int heapDelete( HEAP *heap, int* data);

static void _reheapDown(HEAP *heap, int index)
{
	int child;
	int temp = heap->heapArr[index];

	while ((2 * index + 1) < heap->last) {
		if (heap->heapArr[2 * index + 1] > heap->heapArr[2 * index + 2]) {	// ���� �ڽ��� �����ʺ��� ū ���
			child = 2 * index + 1;
		}
		else {
			child = 2 * index + 2;
		}

		if (temp < heap->heapArr[child]) {
			heap->heapArr[index] = heap->heapArr[child];
		}
		else
			break;

		index = child;
	}
	heap->heapArr[index] = temp;
}

int heapInsert(HEAP *heap, int data)
{
	heap->heapArr[heap->last++] = data;
	_reheapUp(heap, heap->last - 1);

	return data;
}

void heapPrint(HEAP *heap) {
	for (int i = 0; i < heap->last; i++) {
		printf("%5d", heap->heapArr[i]);
	}
	printf("\n");
}

int heapDelete(HEAP *heap, int* data)
{
	if (heap->last == 1) {	// ������ ����� ���
		heap->last = -1;	// loop�� �����Ű�� ���� ����

		*data = heap->heapArr[0];

		return heap->heapArr[0];
	}

	int key = heap->heapArr[0];
	heap->heapArr[0] = heap->heapArr[heap->last - 1];
	heap->last--;
	_reheapDown(heap, 0);

	*data = key;

	return key;
}

int main(void)
{
	HEAP *heap;
	int data;
	
	heap = heapCreate(MAX_ELEM);
	
	srand( time(NULL));
	
	for (int i = 1; i < MAX_ELEM; i++)
	{
		data = rand() % MAX_ELEM * 3 + 1; // 1 ~ MAX_ELEM*3 random number
				
		fprintf( stdout, "Inserting %d: ", data);
		
		// insert function call
		heapInsert( heap, data);
		
		heapPrint( heap);
 	}

	while (heap->last >= 0)
	{
		// delete function call
		heapDelete( heap, &data);

		fprintf( stdout, "Deleting %d: ", data);

		heapPrint( heap);
 	}
	
	heapDestroy( heap);
	
	return 0;
}
