#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct graph {
	int vertices;
	int *vertexdata;
	int **arr;
	int *visitflag;
} GRAPH;

GRAPH *makeGraph(int vertices)
{
	GRAPH *graph = (GRAPH *)calloc(1, sizeof(GRAPH));

	graph->vertexdata = (int *)calloc(1, sizeof(int) * vertices);
	graph->visitflag = (int *)calloc(1, sizeof(int) * vertices);
	graph->arr = (int **)calloc(1, sizeof(int *) * vertices);
	for (int i = 0; i < vertices; i++) {
		graph->arr[i] = (int *)calloc(1, sizeof(int) * vertices);
	}

	graph->vertices = vertices;

	for (int count = 0; count < graph->vertices; count++) {
		graph->vertexdata[count] = count + 1;
	}

	return graph;
}

void destroyGraph(GRAPH * graph)
{
	if (graph == NULL) {
		return;
	}
	if (graph->vertexdata != NULL) {
		free(graph->vertexdata);
	}

	if (graph->visitflag != NULL) {
		free(graph->visitflag);
	}
	if (graph->arr != NULL) {
		for (int i = 0; i < graph->vertices; i++) {
			if (graph->arr[i] != NULL) {
				free(graph->arr[i]);
			}
		}
		free(graph->arr);
	}

	free(graph);
}

struct StackNode {
	int data;
	struct StackNode *next;
};

struct StackNode *newNode(int data)
{
	struct StackNode *stackNode = (struct StackNode *) calloc(1, sizeof(struct StackNode));
	stackNode->data = data;
	return stackNode;
}

int isEmpty(struct StackNode *root)
{
	return !root;
}

void push(struct StackNode **root, int data)
{
	struct StackNode *stackNode = newNode(data);
	stackNode->next = *root;
	*root = stackNode;
}

int pop(struct StackNode **root)
{
	if (isEmpty(*root))
		return -1;
	struct StackNode *temp = *root;
	*root = (*root)->next;
	int popped = temp->data;
	free(temp);
	return popped;
}

int peek(struct StackNode *root)
{
	if (isEmpty(root))
		return -1;
	return root->data;
}

void DFS_Traversal(GRAPH * graph, int start)
{
	struct StackNode *stack = NULL;

	push(&stack, start);
	graph->visitflag[start] = 1;

	while (!isEmpty(stack)) {
		int v2 = peek(stack);
		
		int data = pop(&stack);
		if (data != start) {
			printf("%d ", graph->vertexdata[data]);
		}

		for (int i = start; i < graph->vertices; i++) {
			if (graph->arr[v2][i] == 1 && (graph->visitflag[i] == 0)) {
				push(&stack, i);
				
				graph->visitflag[i] = 1;

			}
		}
		
	}

	free(stack);
}

void DFS(GRAPH * graph)
{
	if (graph == NULL) {
		return;
	}
	int index = 0;
	printf("DFS : ");
	printf("%d ", graph->vertexdata[index]);
	DFS_Traversal(graph, index);
	for (int check = 0; check < graph->vertices; check++) {
		if (graph->visitflag[check] == 0) {
			graph->visitflag[check] = 1;
			printf("%d ", graph->vertexdata[check]);
			DFS_Traversal(graph, check);
		}
	}
	printf("\n");
}

struct QNode {
	int key;
	struct QNode *next;
};

struct Queue {
	struct QNode *front, *rear;
};

struct QNode *newQueueNode(int k)
{
	struct QNode *temp = (struct QNode *) calloc(1, sizeof(struct QNode));
	temp->key = k;
	return temp;
}

struct Queue *createQueue()
{
	struct Queue *q = (struct Queue *) calloc(1, sizeof(struct Queue));
	return q;
}

int isQueueEmpty(struct Queue *q)
{
	return (q->front == q->rear);
}


void enQueue(struct Queue *q, int k)
{
	struct QNode *temp = newQueueNode(k);

	if (q->rear == NULL) {
		q->front = q->rear = temp;
		return;
	}

	q->rear->next = temp;
	q->rear = temp;
}

struct QNode *deQueue(struct Queue *q)
{
	if (q->front == NULL)
		return NULL;

	struct QNode *temp = q->front;
	q->front = q->front->next;

	if (q->front == NULL)
		q->rear = NULL;

	return temp;
}

void BFS_Traversal(GRAPH * graph, int start)
{
	struct Queue *q = createQueue();

	enQueue(q, start);
	graph->visitflag[start] = 1;

	struct QNode *n;
	while ((n = deQueue(q)) != NULL) {
		int v2 = n->key;
		printf("%d ", graph->vertexdata[v2]);
		free(n);
		for (int i = 0; i < graph->vertices; i++) {
			if (graph->arr[v2][i] == 1 && (graph->visitflag[i] == 0)) {
				enQueue(q, i);
				graph->visitflag[i] = 1;
			}
		}
	}

	free(q);
}

void BFS(GRAPH * graph)
{
	if (graph == NULL) {
		return;
	}

	printf("BFS : ");
	for (int index = 0; index < graph->vertices; index++) {
		if (graph->visitflag[index] == 0) {
			BFS_Traversal(graph, index);
		}
	}
	printf("\n");
}

int main(int argc, char *argv[])
{
	FILE *stream;
	char *line = NULL;
	size_t len = 0;
	ssize_t nread;
	int vertices, from, to;

	if (argc != 2) {
		fprintf(stderr, "Usage: %s FILE\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	stream = fopen(argv[1], "r");
	if (stream == NULL) {
		perror("fopen");
		exit(EXIT_FAILURE);
	}

	GRAPH *graph = NULL;

	if ((nread = getline(&line, &len, stream)) == -1) {
		exit(EXIT_FAILURE);
	}
	if (strncmp(line, "*Vertices", strlen("*Vertices")) != 0) {
		exit(EXIT_FAILURE);
	}

	sscanf(line, "%*s%d", &vertices);

	if ((nread = getline(&line, &len, stream)) == -1) {
		exit(EXIT_FAILURE);
	}
	if (strncmp(line, "*Edges", strlen("*Edges")) != 0) {
		exit(EXIT_FAILURE);
	}

	graph = makeGraph(vertices);

	while ((nread = getline(&line, &len, stream)) != -1) {
		sscanf(line, "%d %d", &from, &to);
		from--;
		to--;
		graph->arr[from][to] = 1;
		graph->arr[to][from] = 1;
	}
	free(line);
	fclose(stream);

	DFS(graph);

	for (int j = 0; j < graph->vertices; j++) {
		graph->visitflag[j] = 0;
	}

	BFS(graph);

	destroyGraph(graph);

	exit(EXIT_SUCCESS);

	return 0;
}