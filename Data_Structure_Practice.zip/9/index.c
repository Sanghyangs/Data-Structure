#define DEBUG 0

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <ctype.h>

// 토큰-문서 구조체
typedef struct {
    char *token;		// 토큰
    int docid;			// 문서번호(document ID)
} tTokenDoc;

typedef struct {
    int index;			// starting position in posting.idx
    int df;			// 문서 빈도(document frequency)
} tHEADER;


////////////////////////////////////////////////////////////////////////////////
// 토큰 구조체로부터 역색인 파일을 생성한다.
void invertedIndex(tTokenDoc * tokens, int num_tokens, char *dicfilename, char *headerfilename, char *postingfilename)
{
    FILE *fpDic, *fpHeader, *fpPosting;
    tHEADER *headerIdx = NULL;
    int *postingIdx = NULL;
    int headerCnt = 0, postingCnt = 0;
    int df;

    const char *tok = tokens[0].token;
    int docId = tokens[0].docid;

    fpDic = fopen(dicfilename, "w");
    if (fpDic == NULL) {
	printf("fopen(%s) failed.\n", dicfilename);
	return;
    }

    headerIdx = (tHEADER *) realloc(headerIdx, sizeof(tHEADER) * (500000));
    if (headerIdx == NULL) {
	perror("realloc(headerIdx)");
	return;
    }

    headerIdx[headerCnt].df = 1;
    headerIdx[headerCnt].index = 0;
    headerCnt++;

    //fwrite(tokens[i].token, 1, strlen(tokens[i].token), fp);
    fprintf(fpDic, "%s\n", tokens[0].token);

    postingIdx = (int *) realloc(postingIdx, sizeof(int) * (700000));
    if (postingIdx == NULL) {
	free(headerIdx);
	perror("realloc(postingIdx)");
	return;
    }
    postingIdx[postingCnt] = docId;
    postingCnt++;

    tHEADER *prevHeader = (tHEADER *) & headerIdx[0];
    int i = 1;

    while (i < num_tokens) {
	if (strcmp(tokens[i].token, tok) != 0) {
	    //headerIdx = (tHEADER *)realloc(headerIdx, sizeof(tHEADER) * (headerCnt + 1));
	    headerIdx[headerCnt].df = 1;
	    headerIdx[headerCnt].index = (prevHeader->index + prevHeader->df);

	    //postingIdx = (int *)realloc(postingIdx, sizeof(int) * (postingCnt + 1));
	    postingIdx[postingCnt] = tokens[i].docid;
	    postingCnt++;

	    fprintf(fpDic, "%s\n", tokens[i].token);

	    tok = tokens[i].token;
	    docId = tokens[i].docid;

	    headerCnt++;
	    prevHeader++;
	} else {
	    if (tokens[i].docid != docId) {
		headerIdx[headerCnt - 1].df += 1;

		//postingIdx = (int *)realloc(postingIdx, sizeof(int) * (postingCnt + 1));
		postingIdx[postingCnt] = tokens[i].docid;
		postingCnt++;

		docId = tokens[i].docid;
	    }
	}

	i++;
    }

    fpHeader = fopen(headerfilename, "wb");
    if (fpHeader == NULL) {
	free(headerIdx);
	free(postingIdx);
	printf("fopen(%s) failed.\n", headerfilename);
	return;
    }

    fpPosting = fopen(postingfilename, "wb");
    if (fpPosting == NULL) {
	free(headerIdx);
	free(postingIdx);
	printf("fopen(%s) failed.\n", postingfilename);
	fclose(fpHeader);
	return;
    }

    fwrite((const void *) headerIdx, sizeof(tHEADER), headerCnt, fpHeader);
    fwrite((const void *) postingIdx, sizeof(int), postingCnt, fpPosting);

    free(headerIdx);
    free(postingIdx);

    fclose(fpDic);
    fclose(fpHeader);
    fclose(fpPosting);
}

// 입력 파일로부터 토큰-문서 구조체를 생성한다.
tTokenDoc *get_tokens(char *filename, int *num_tokens)
{
    FILE *stream;
    char *line = NULL;
    size_t len = 0;
    ssize_t nread;
    int docNum = 0, tokenCount = 0;
    tTokenDoc *tokens = NULL;

    stream = fopen(filename, "r");
    if (stream == NULL) {
	perror("fopen");
	exit(EXIT_FAILURE);
    }

    *num_tokens = tokenCount;
    tokens = realloc(tokens, sizeof(tTokenDoc) * 700000);
    if (tokens == NULL) {
	perror("realloc(token)");
	return NULL;
    }

    while ((nread = getline(&line, &len, stream)) != -1) {
	char *str1, *token;	// , *str2, *subtoken;
	char *saveptr1;		// , *saveptr2;
	int j;

	docNum++;

	for (j = 1, str1 = line;; j++, str1 = NULL) {
	    token = strtok_r(str1, " \n", &saveptr1);
	    if (token == NULL)
		break;

	    //tokens = realloc(tokens, sizeof(tTokenDoc) * j);
	    tokens[tokenCount].token = strdup( /*tolower */ (token));
	    tokens[tokenCount].docid = docNum;

	    tokenCount++;
	}
    }

    free(line);
    fclose(stream);

    *num_tokens = tokenCount;
    return tokens;
}

// qsort를 위한 비교함수 (첫번째 정렬 기준: 토큰 문자열, 두번째 정렬 기준: 문서 번호)
static int _compare(const void *n1, const void *n2)
{
    tTokenDoc *arg1, *arg2;
    int comp;

    arg1 = (tTokenDoc *) n1;
    arg2 = (tTokenDoc *) n2;
    comp = strcmp(arg1->token, arg2->token);
    if (comp != 0) {
	return comp;
    }

    if (arg1->docid < arg2->docid) {
	return -1;
    }

    if (arg1->docid == arg2->docid) {
	return 0;
    }

    return 1;
}

////////////////////////////////////////////////////////////////////////////////
static void print_tokens(tTokenDoc * tokens, int num_tokens)
{
    int i;

    for (i = 0; i < num_tokens; i++) {
	printf("%s\t%d\n", tokens[i].token, tokens[i].docid);
    }
}

////////////////////////////////////////////////////////////////////////////////
void destroy_tokens(tTokenDoc * tokens, int num_tokens)
{
    int i;

    for (i = 0; i < num_tokens; i++) {
	free(tokens[i].token);
    }
    free(tokens);
}

////////////////////////////////////////////////////////////////////////////////
int main(int argc, char **argv)
{
    tTokenDoc *tokens;
    int num_tokens = 0;

    if (argc != 2) {
	printf("Usage: %s FILE\n", argv[0]);
	return 2;
    }

    tokens = get_tokens(argv[1], &num_tokens);

    assert(tokens != NULL && num_tokens > 0);

#if DEBUG
    print_tokens(tokens, num_tokens);
#endif

    // 정렬 (첫번째 정렬 기준: 토큰 문자열, 두번째 정렬 기준: 문서 번호)
    qsort(tokens, num_tokens, sizeof(tTokenDoc), _compare);

    invertedIndex(tokens, num_tokens, "dic.txt", "header.idx", "posting.idx");

#if DEBUG
    print_tokens(tokens, num_tokens);
#endif

    destroy_tokens(tokens, num_tokens);

    return 0;
}
