#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>		// isupper, tolower

#include "trie.h"
    
////////////////////////////////////////////////////////////////////////////////
// Prototype declarations
    
/* Allocates dynamic memory for a trie node and returns its address to caller
	return	node pointer
			NULL if overflow
*/ 
    TRIE * trieCreateNode(void)
{
    TRIE * trie = (TRIE *) calloc(1, sizeof(TRIE));
    if (trie != NULL) {
	trie->index = -1;
    }
    return trie;
}

 
/* Deletes all data in trie and recycles memory
*/ 
void trieDestroy(TRIE * root)
{
    if (root == NULL) {
	return;
    }
     for (int i = 0; i < MAX_DEGREE; i++) {
	trieDestroy(root->subtrees[i]);
    }  free(root);
    root = NULL;
}  

/* Inserts new entry into the trie
	return	1 success
			0 failure
*/ 
// 주의! 엔트리를 중복 삽입하지 않도록 체크해야 함
// 대소문자를 소문자로 통일하여 삽입
// 영문자 외 문자를 포함하는 문자열은 삽입하지 않음
int trieInsert(TRIE * root, char *str, int dic_index)
{
    for (int i = 0; i < strlen(str); i++) {
	if (isalpha(str[i]) == 0) {
	    if (str[i] != '$')
		return 0;
	}
    }
    for (int i = 0; i < strlen(str); i++) {
	str[i] = tolower(str[i]);
    }  TRIE * current = root;
    int position;
    for (int i = 0; i < strlen(str); i++)
	 {
	position = getIndex(str[i]);
	if (current->subtrees[position] == NULL) {
	    current->subtrees[position] = trieCreateNode();
	}
	 current = current->subtrees[position];
	}
     current->index = dic_index;
     return 1;
}

 
/* Retrieve trie for the requested key
	return	index in dictionary (trie) if key found
			-1 key not found
*/ 
int trieSearch(TRIE * root, char *str)
{
    for (int i = 0; i < strlen(str); i++) {
	if (isalpha(str[i]) == 0)
	    return -1;
    }
    for (int i = 0; i < strlen(str); i++) {
	str[i] = tolower(str[i]);
    }  TRIE * current = root;
    int position;
    for (int i = 0; i < strlen(str); i++)
	 {
	position = getIndex(str[i]);
	if (current->subtrees[position] == NULL) {
	    return -1;
	}
	 current = current->subtrees[position];
	}
     return current->index;
}

 
/* prints all entries in trie using preorder traversal
*/ 
void trieList(TRIE * root)
{
    printf("%d\n", root->index);
     for (int i = 0; i < MAX_DEGREE; i++) {
	if (root->subtrees[i] != NULL)
	    trieList(root->subtrees[i]);
    }
}

 
/* prints all entries starting with str (as prefix) in trie
   ex) "abb" -> "abbas", "abbasid", "abbess", ...
	using trieList function
*/ 
void triePrefixList(TRIE * root, char *str)
{
    TRIE * current = root;
    int len = strlen(str);
    for (int i = 0; i < len; i++)
	 {
	int index = getIndex(str[i]);
	if ((index < 0) || (index >= MAX_DEGREE)) {
	    return;
	}
	if (current->subtrees[index] == NULL) {
	    return;
	}
	 current = current->subtrees[index];
	}
     trieList(current);
}

 
/* makes permuterms for given str
	ex) "abc" -> "abc$", "bc$a", "c$ab", "$abc"
	return	number of permuterms
*/ 
int make_permuterms(char *str, char *permuterms[])
{
    int len = strlen(str) + 1;
    char term[100], temp[100];
     memset((char *) &temp[0], 0x00, sizeof(temp));
    memset((char *) &term[0], 0x00, sizeof(term));
    sprintf(term, "%s$", str);
     for (int i = 0; i < len; i++)
	 {
	int j = i;
	int k = 0;
	 while (term[j] != '\0')
	     {
	    temp[k] = term[j];
	    k++;
	    j++;
	    }
	 j = 0;
	while (j < i)
	     {
	    temp[k] = term[j];
	    j++;
	    k++;
	    }
	 permuterms[i] = strdup(temp);
	}
     return len;
}

 
/* recycles memory for permuterms
*/ 
void clear_permuterms(char *permuterms[], int size)
{
    for (int i = 0; i < size; i++) {
	free(permuterms[i]);
} }  

/* wildcard search
	ex) "ab*", "*ab", "a*b", "*ab*"
	using triePrefixList function
*/ 
void trieSearchWildcard(TRIE * root, char *str)
{
    char *p1, *p2, *p3, *key;
    int star = 0;
     for (int i = 0; i < strlen(str); i++) {
	if (str[i] == '*') {
	    star++;
	}
    }
    switch (star) {
    case 0:
	break;
     case 1:
	break;
     case 2:
	if ((str[0] == '*') && (str[strlen(str) - 1] == '*')) {
	}
	
	else {
	    return;
	}
	break;
     default:
	return;
    }
     key = (char *) calloc(1, strlen(str) + 2 /* 1: $, 1: '\0' */ );
    if ((str[0] == '*') && (str[strlen(str) - 1]) == '*') {
	char *p = &str[1];
	str[strlen(str) - 1] = '\0';
	sprintf(key, "%s", p);
	str[strlen(str) - 1] = '*';
    }
    
    else {
	p1 = strchr(str, '*');
	p1++;
	sprintf(key, "%s", p1);
	p2 = key + strlen(p1);
	p1--;
	*p1 = '\0';
	sprintf(p2, "$%s", str);
	*p1 = '*';
    }
     for (int i = 0; i < strlen(key); i++) {
	key[i] = tolower(key[i]);
    }  triePrefixList(root, key);
    free(key);
}  

/* makes a trie for given dictionary file
	return	trie head node pointer
			NULL failure
*/ 
    TRIE * dic2trie(char *dicfile)
{
    TRIE * trie = NULL;
    FILE * fp;
    char *line = NULL, word[128];
    size_t len = 0;
    ssize_t nread;
    int linecnt = 0;
     trie = trieCreateNode();
    if (trie == NULL) {
	printf("trie create error!\n");
	return NULL;
    }
    fp = fopen(dicfile, "r");
    if (fp == NULL) {
	printf("fopen error!\n");
	return NULL;
    }
     printf("Inserting to trie...");
     while ((nread = getline(&line, &len, fp)) != -1) {
	sscanf(line, "%s", word);
	if (trieInsert(trie, word, linecnt) != 1) {
	    printf("trieInsert error!\n");
	    trieDestroy(trie);
	    return NULL;
	}
	 linecnt++;
    }
     free(line);
    fclose(fp);
     printf("\t[done]");
     return trie;
}

  
/* makes a permuterm trie for given dictionary file
	return	trie head node pointer
			NULL failure
*/ 
    TRIE * dic2permute_trie(char *dicfile);

