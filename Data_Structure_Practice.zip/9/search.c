//#define DEBUG 1

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "trie.h"

// 역색인 헤더 정보에 대한 구조체
typedef struct {
    int index;			// starting position in posting.idx
    int df;			// document frequency
} tHEADER;

////////////////////////////////////////////////////////////////////////////////
// 헤더 정보가 저장된 파일(예) "header.idx")을 읽어 메모리에 저장한다.
// 헤더 구조체 메모리를 할당하고 그 주소를 반환
// 실패시 NULL을 반환
tHEADER *load_header(char *filename)
{
    FILE *fp;
    size_t nmemb;
    struct stat statbuf;
    tHEADER *header = NULL;
    int size;

    fp = fopen(filename, "rb");
    if (fp == NULL) {
	printf("fopen(%s) error !\n", filename);
	return NULL;
    }

    if (stat(filename, &statbuf) != 0) {
	fclose(fp);
	perror("stat");
	return NULL;
    }

    size = statbuf.st_size;
    nmemb = size / sizeof(tHEADER);

    header = (tHEADER *) calloc(1, size);
    if (header == NULL) {
	fclose(fp);
	perror("calloc");
	return NULL;
    }


    int nread = fread((void *) header, sizeof(tHEADER), nmemb, fp);
    if (nread != nmemb) {
	fclose(fp);
	free(header);
	perror("fread");
	return NULL;
    }

    fclose(fp);

    return header;
}

// 포스팅 리스트가 저장된 파일(예) "posting.idx")를 읽어 메모리에 저장한다.
// 포스팅 리스트(int arrary) 메모리를 할당하고 그 주소를 반환
// 실패시 NULL을 반환
int *load_posting(char *filename)
{
    FILE *fp;
    size_t nmemb;
    struct stat statbuf;
    int *posting;
    int size;

    fp = fopen(filename, "rb");
    if (fp == NULL) {
	printf("fopen(%s) error !\n", filename);
	return NULL;
    }

    if (stat(filename, &statbuf) != 0) {
	fclose(fp);
	perror("stat");
	return NULL;
    }

    size = statbuf.st_size;
    nmemb = size / sizeof(int);

    posting = (int *) calloc(1, size);
    if (posting == NULL) {
	fclose(fp);
	perror("calloc");
	return NULL;
    }

    int nread = fread((void *) posting, sizeof(int), nmemb, fp);
    if (nread != nmemb) {
	fclose(fp);
	free(posting);
	perror("fread");
	return NULL;
    }

    fclose(fp);


    return posting;
}

// 문서 집합을 화면에 출력한다.
void showDocuments(int *docs, int numdocs)
{
    for (int index = 0; index < numdocs; index++) {
	printf(" %d", docs[index]);
    }
    printf("\n");

    return;
}

// 두 문서 집합의 교집합을 구한다.
// 교집합을 위한 메모리를 할당하고 그 주소를 반환
// 실패시 NULL을 반환
// 교집합의 문서 수는 newnumdocs에 저장한다.
int *intersectDocuments(int *docs, int numdocs, int *docs2, int numdocs2, int *newnumdocs)
{
    int *docSet = 0;
    int len = numdocs;
    int i = 0, j = 0, k = 0;

    if (numdocs < numdocs2) {
	len = numdocs2;
    }
    docSet = (int *) calloc(len, sizeof(int));
    if (docSet == NULL) {
	*newnumdocs = 0;
	return 0;
    }

    while ((i < numdocs) && (j < numdocs2)) {
	if (docs[i] < docs2[j]) {
	    i++;
	} else if (docs[i] > docs2[j]) {
	    j++;
	} else {
	    docSet[k] = docs[i];
	    i++;
	    j++;
	    k++;
	}
    }

    *newnumdocs = k;

    return docSet;
}

// 두 문서 집합의 합집합을 구한다.
// 합집합을 위한 메모리를 할당하고 그 주소를 반환
// 실패시 NULL을 반환
// 합집합의 문서 수는 newnumdocs에 저장한다.
int *unionDocuments(int *docs, int numdocs, int *docs2, int numdocs2, int *newnumdocs)
{
    int *docSet = 0;
    int len = numdocs + numdocs2;
    int i = 0, j = 0, k = 0;

    docSet = (int *) calloc(len, sizeof(int));
    if (docSet == NULL) {
	newnumdocs = 0;
	return 0;
    }

    while ((i < numdocs) && (j < numdocs2)) {
	if (docs[i] < docs2[j]) {
	    docSet[k] = docs[i];
	    i++;
	    k++;
	} else if (docs[i] > docs2[j]) {
	    docSet[k] = docs2[j];
	    j++;
	    k++;
	} else {
	    docSet[k] = docs[i];
	    i++;
	    j++;
	    k++;
	}
    }

    if (i == numdocs) {
	while (j < numdocs2) {
	    docSet[k] = docs2[j];
	    j++;
	    k++;
	}
    } else {
	while (i < numdocs2) {
	    docSet[k] = docs[i];
	    i++;
	    k++;
	}
    }

    *newnumdocs = k;

    return docSet;
}

static char *ltrim(char *str);
static char *rtrim(char *str);
static char *trim(char *str);

// 단일 텀(single term)을 검색하여 문서를 찾는다.
// 문서 집합을 위한 메모리를 할당하고 그 주소를 반환
// 실패시 NULL을 반환
// 검색된 문서 수는 newnumdocs에 저장한다.
int *getDocuments(tHEADER * header, int *posting, TRIE * trie, char *term, int *numdocs)
{
    int *docSet = 0;
    char *query = trim(term);
    int index, hdrIdx, hdrDf;

    index = trieSearch(trie, query);
    if (index < 0) {
	*numdocs = 0;
	return NULL;
    }

    hdrIdx = header[index].index;
    hdrDf = header[index].df;

    docSet = (int *) calloc(hdrDf, sizeof(int));
    if (docSet == NULL) {
	perror("calloc");
	*numdocs = 0;
	return NULL;
    }

    *numdocs = hdrDf;
    memcpy((char *) &docSet[0], (char *) &posting[hdrIdx], sizeof(int) * hdrDf);

    return docSet;
}

// 질의(query)를 검색하여 문서를 찾는다.
// 질의는 단일 텀 또는 하나 이상의 불린 연산자('&' 또는 '|')를 포함한 질의가 될 수 있다.
// 문서 집합을 위한 메모리를 할당하고 그 주소를 반환
// 실패시 NULL을 반환
// 검색된 문서 수는 newnumdocs에 저장한다.
int *searchDocuments(tHEADER * header, int *posting, TRIE * trie, char *query, int *numdocs)
{
    int *docSet = NULL;
    int entry = 0;

    *numdocs = 0;
    char *querytrimed = ltrim(query);
    char *query2, *token, *tmp;
    char op = ' ';
    int pos;

    if (querytrimed == NULL) {
	//if (strlen(querytrimed) < 1) {
	*numdocs = 0;
	return NULL;
    }

    docSet = (int *) calloc(100000, sizeof(int));
    if (docSet == NULL) {
	*numdocs = 0;
	return NULL;
    }

    query2 = strdup(querytrimed);
    tmp = query2;

    while ((token = strsep(&tmp, "&|")) != NULL) {
	int numdocs2;
	numdocs2 = 0;
	if (op == ' ') {
	    int *tmpDoc = getDocuments(header, posting, trie, token, &numdocs2);
	    if (tmpDoc == NULL) {
		free(query2);
		*numdocs = 0;
		free(docSet);
		return NULL;
	    }

	    memcpy((char *) &docSet[entry], (char *) &tmpDoc[0], numdocs2 * (sizeof(int)));
	    free(tmpDoc);
	    entry += numdocs2;
	} else {
	    if (strlen(token) > 0) {
		token = ltrim(token);
	    }
	    if (token != NULL) {
		token = rtrim(token);
	    }
	    if ((token != NULL) && (strlen(token) > 0)) {
		int *tmpDoc = getDocuments(header, posting, trie, token, &numdocs2);
		if (tmpDoc == NULL) {
		    free(query2);
		    *numdocs = 0;
		    free(docSet);
		    return NULL;
		}
		int *tmpDoc2;
		int newnumdocs;
		switch (op) {
		case '|':
		    tmpDoc2 = unionDocuments(docSet, entry, tmpDoc, numdocs2, &newnumdocs);
		    memcpy((char *) &docSet[0], (char *) &tmpDoc2[0], newnumdocs * (sizeof(int)));
		    entry = newnumdocs;
		    free(tmpDoc);
		    free(tmpDoc2);
		    break;

		case '&':
		    tmpDoc2 = intersectDocuments(docSet, entry, tmpDoc, numdocs2, &newnumdocs);
		    memcpy((char *) &docSet[0], (char *) &tmpDoc2[0], newnumdocs * (sizeof(int)));
		    entry = newnumdocs;
		    free(tmpDoc);
		    free(tmpDoc2);
		    break;

		default:
		    break;
		}
	    } else if (op == '&') {
		entry = 0;
	    }

	}
	if (tmp != NULL) {
	    pos = strlen(query) - strlen(tmp) - 1;
	    op = query[pos];
	}
    }

    free(query2);
    if (entry == 0) {
	free(docSet);
	return NULL;
    }

    *numdocs = entry;

    return docSet;
}

////////////////////////////////////////////////////////////////////////////////
static char *rtrim(char *str)
{
    char *p = str + strlen(str) - 1;

    while (p >= str) {
	if (*p == '\n' || *p == ' ' || *p == '\t')
	    *p = 0;
	else
	    return str;
	p--;
    }
}

static char *ltrim(char *str)
{
    char *p = str;

    while (*p) {
	if (*p == '\n' || *p == ' ' || *p == '\t')
	    p++;
	else {
	    return p;
	}
    }
    return NULL;
}

static char *trim(char *str)
{
    if (str == NULL || *str == 0)
	return str;

    return rtrim(ltrim(str));
}

////////////////////////////////////////////////////////////////////////////////
int main(int argc, char **argv)
{
    tHEADER *header;
    int *posting;
    TRIE *trie;
    char query[100];
    int index;

    header = load_header("header.idx");
    if (header == NULL)
	return 1;

    posting = load_posting("posting.idx");
    if (posting == NULL)
	return 1;

    trie = dic2trie("dic.txt");

    printf("\nQuery: ");

    while (fgets(query, 100, stdin) != NULL) {
	int numdocs;
	int *docs = searchDocuments(header, posting, trie, query, &numdocs);

	if (docs == NULL)
	    printf("not found!\n");
	else {
	    showDocuments(docs, numdocs);
	    free(docs);
	}
	printf("\nQuery: ");
    }

    free(header);
    free(posting);
    trieDestroy(trie);

    return 0;
}
