#include <stdlib.h> // malloc, atoi
#include <stdio.h>
#include <ctype.h> // isdigit
#include <assert.h> // assert
#include <string.h>

#define MAX_STACK_SIZE	50

////////////////////////////////////////////////////////////////////////////////
// LIST type definition
typedef struct node
{
	char		data;
	struct node	*left;
	struct node	*right;
} NODE;

typedef struct
{
	NODE	*root;
} TREE;

////////////////////////////////////////////////////////////////////////////////
// Prototype declarations

/* Allocates dynamic memory for a tree head node and returns its address to caller
	return	head node pointer
	NULL if overflow
*/
TREE *createTree( void);

/* Deletes all data in tree and recycles memory
	return	NULL head pointer
*/
TREE *destroyTree( TREE *pTree);
static void _destroy(NODE *root)
{
	if (root->left != NULL) _destroy(root->left);
	if (root->right != NULL) _destroy(root->right);

	free(root);
}

/*  Allocates dynamic memory for a node and returns its address to caller
	return	node pointer
	NULL if overflow
*/
static NODE *_makeNode(char ch)
{
	NODE *node = (NODE *)calloc(1, sizeof(NODE));
	if (node) {
		node->data = ch;
	}

	return node;
}

/* converts postfix expression to binary tree
	return	1 success
		0 invalid postfix expression
*/
int postfix2tree( char *expr, TREE *pTree);

/* Print node in tree using inorder traversal
*/
void traverseTree( TREE *pTree);

/* internal traversal function
	an implementation of ALGORITHM 6-6
*/
static void _traverse(NODE *root)
{
	if (root != NULL) {
		char ch = root->data;
		switch (ch) {
		case '+':
		case '-':
		case '*':
		case '/':
			printf("(");
			_traverse(root->left);
			printf("%c", ch);
			_traverse(root->right);
			printf(")");
			break;

		default:
			_traverse(root->left);
			printf("%c", ch);
			_traverse(root->right);
			break;
		}
	}
}

/* Print tree using inorder right-to-left traversal
*/
void printTree( TREE *pTree);

/* internal traversal function
*/
static void _infix_print(NODE *root, int level)
{
	int current = level;
	if (root->right != NULL) {
		_infix_print(root->right, current + 1);
	}
	for (int index = 0; index < level; index++) {
		printf("\t");
	}
	printf("%c\n", root->data);

	if (root->left != NULL) {
		_infix_print(root->left, current + 1);
	}
}

/* evaluate postfix expression
	return	value of expression
*/
float evalPostfix( char *expr)
{
	int top = -1;
	float ret;
	float stack[MAX_STACK_SIZE];
        for (int index = 0; index < strlen(expr); index++) {
		float op1, op2, value, result;
                char ch = expr[index];
                switch (ch) {
                case '+':
			op2 = stack[top--];
			op1 = stack[top--];
			result = op1 + op2;
			stack[++top] = result;
			break;

                case '-':
			op2 = stack[top--];
			op1 = stack[top--];
			result = op1 - op2;
			stack[++top] = result;
			break;

                case '*':
			op2 = stack[top--];
			op1 = stack[top--];
			result = op1 * op2;
			stack[++top] = result;
			break;

                case '/':
			op2 = stack[top--];
			op1 = stack[top--];
			result = op1 / op2;
			stack[++top] = result;
			break;

                default:
			value = ch - 0x30;
			stack[++top] = value;
                        break;
                }
        }

	return stack[top];
}

////////////////////////////////////////////////////////////////////////////////
TREE *destroyTree( TREE *pTree)
{
	if (pTree == NULL) {
		return NULL;
	}
	if (pTree->root == NULL) {
		free(pTree);
		return NULL;
	}

	_destroy( pTree->root);
	free( pTree);

	return NULL;	
}

////////////////////////////////////////////////////////////////////////////////
void printTree( TREE *pTree)
{
	_infix_print(pTree->root, 0);
	
	return;
}

////////////////////////////////////////////////////////////////////////////////
void traverseTree( TREE *pTree)
{
	_traverse(pTree->root);
	
	return;
}

TREE *createTree(void)
{
	TREE *tree = (TREE *)calloc(1, sizeof(TREE));
	return tree;
}

int postfix2tree(char *expr, TREE *pTree)
{
	int top = -1;
	NODE *stack[MAX_STACK_SIZE] = { 0, };

	/*
	 * postfix expression�� ��ȿ���� �˻��Ѵ�. 
	 */
	int validExpr = 0;
	for (int index = 0; index < strlen(expr); index++) {
		char ch = expr[index];
		switch (ch) {
		case '+':
		case '-':
		case '*':
		case '/':
			validExpr--;
			break;

		default:
			if (isdigit(ch) == 0) {
				destroyTree(pTree);
				return 0;
			}
			validExpr++;
			break;
		}
	}
	if (validExpr != 1) {
		/*
		��ȿ�� postfix expression�� operand�� ���� operator�� �� ���� 1�� �� ���ƾ� �Ѵ�.
		*/
		//free(pTree);
		destroyTree(pTree);
		return 0;
	}
	if ((isdigit(expr[0]) == 0) || (isdigit(expr[1]) == 0)) {
		/*
		��ȿ�� postfix expression�� ó�� 2���� �ݵ�� operand���� �Ѵ�.
		*/
		//free(pTree);
		destroyTree(pTree);
		return 0;
	}
	if (isdigit(expr[strlen(expr)-1]) != 0) {
		/*
		��ȿ�� postfix expression�� ���������� �ݵ�� operator���� �Ѵ�.
		*/
		//free(pTree);
		destroyTree(pTree);
		return 0;
	}

	/*
	postfix expression tree�� �����.
	*/
	for (int index = 0; index < strlen(expr); index++) {
		char ch = expr[index];
		NODE *newnode = _makeNode(ch);
		switch (ch) {
		case '+':
		case '-':
		case '*':
		case '/':
			newnode->right = stack[top--]; stack[top + 1] = NULL;
			newnode->left = stack[top--]; stack[top + 1] = NULL;
			break;

		default:
			break;
		}

		stack[++top] = newnode;
	}

	/*
	postfix expression tree�� ��ȯ�Ѵ�.
	*/
	pTree->root = stack[top];

	return 1;
}
////////////////////////////////////////////////////////////////////////////////
int main( int argc, char **argv)
{
	TREE *tree;
	char expr[1024];
	
	fprintf( stdout, "\nInput an expression (postfix): ");
	
	while (fscanf( stdin, "%s", expr) == 1)
	{
		// creates a null tree
		tree = createTree();
		
		if (!tree)
		{
			printf( "Cannot create tree\n");
			return 100;
		}
		
		// postfix expression -> expression tree
		int ret = postfix2tree( expr, tree);
		if (!ret)
		{
			fprintf( stdout, "invalid expression!\n");
			continue;
		}
		
		// expression tree -> infix expression
		fprintf( stdout, "\nInfix expression : ");
		traverseTree( tree);
		
		// print tree with right-to-left infix traversal
		fprintf( stdout, "\n\nTree representation:\n");
		printTree(tree);
		
		// evaluate postfix expression
		float val = evalPostfix( expr);
		fprintf( stdout, "\nValue = %f\n", val);
		
		// destroy tree
		destroyTree( tree);
		
		fprintf( stdout, "\nInput an expression (postfix): ");
	}
	return 0;
}
