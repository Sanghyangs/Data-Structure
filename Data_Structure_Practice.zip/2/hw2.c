#include <stdlib.h> // malloc
#include <stdio.h>
#include <string.h> // strdup, strcmp

// User structure type definition
typedef struct
{
	char	*token;
	int		freq;
} tTOKEN;

////////////////////////////////////////////////////////////////////////////////
// LIST type definition
typedef struct node
{
	tTOKEN		*dataPtr;
	struct node	*link;
} NODE;

typedef struct
{
	int		count;
	NODE	*pos;
	NODE	*head;
	NODE	*rear;
} LIST;

////////////////////////////////////////////////////////////////////////////////
// Prototype declarations

/* Allocates dynamic memory for a list head node and returns its address to caller
return	head node pointer
NULL if overflow
*/
LIST *createList(void) {

	LIST *head;

	head = (LIST *)calloc(1, sizeof(LIST));

	return head;
}

tTOKEN *destroyToken(tTOKEN *pToken);

/* Deletes all data in list and recycles memory
return	NULL head pointer
*/
LIST *destroyList(LIST *pList) {
	NODE *next, *node = pList->head;

        if (pList->count == 0) {
                free(pList);
                return NULL;
        }

	while (node != NULL) {
		tTOKEN *pToken;

		next = node->link;

		pToken = node->dataPtr;
		destroyToken(pToken);

		free(node);

		node = next;
	}

	free(pList);

	return NULL;
}

static int _search(LIST *pList, NODE **pPre, NODE **pLoc, tTOKEN *dataInPtr);

/* Inserts data into list
return	-1 if overflow
0 if successful
1 if duplicated key
*/
int addNode(LIST *pList, tTOKEN *dataInPtr) {

	NODE *node;
	NODE *pPre = NULL, *pLoc = NULL;

	node = (NODE *)calloc(1, sizeof(NODE));
	if (node == NULL) {
		return -1;
	}

	if (pList->count == 0) {
		pList->head = node;
		pList->rear = node;
		pList->pos = node;
		pList->count++;

		node->dataPtr = dataInPtr;

		return 0;
	}

	if (_search(pList, &pPre, &pLoc, dataInPtr) == 1) {
		free(node);

		pLoc->dataPtr->freq++;

		return 1;
	}

	node->dataPtr = dataInPtr;
	if (pPre == NULL) {
		node->link = pLoc;

		pList->head = node;
	} else if (pLoc == NULL) {
                pPre->link = node;
                node->link = pLoc;
                pList->rear = node;
	} else {
                pPre->link = node;
                node->link = pLoc;
	}

	pList->count++;

	return 0;
}

/* Removes data from list
return	0 not found
1 deleted
*/
int removeNode(LIST *pList, char *keyPtr, tTOKEN **dataOut) {
	NODE *pPre = NULL, *pLoc = NULL;
	tTOKEN *tok = createToken(keyPtr);

	if (_search(pList, &pPre, &pLoc, tok) == 1) {
		tTOKEN* tok2;
		_delete(pList, pPre, pLoc, &tok2);

		*dataOut = tok2;

		printf("Found %s\n", tok2->token);

		return 1;
	}

	printf("Not found: %s\n", keyPtr);
	return 0;
}

/* interface to search function
Argu	key being sought
dataOut	contains found data
return	1 successful
0 not found
*/
int searchList(LIST *pList, char *pArgu, tTOKEN **pDataOut) {
	NODE *pPre = NULL, *pLoc = NULL;
	tTOKEN *tok = createToken(pArgu);

	if (_search(pList, &pPre, &pLoc, tok) == 1) {
		
		*pDataOut = pLoc->dataPtr;

		destroyToken(tok);

		return 1;
	}

	destroyToken(tok);

	return 0;
}

/* returns number of nodes in list
*/
int listCount(LIST *pList) {
	return pList->count;
}

/* returns	1 empty
0 list has data
*/
int emptyList(LIST *pList) {
	if (pList->count == 0)
		return 1;

	return 0;
}

//int fullList( LIST *pList);

/* prints data from list
*/
void printList(LIST *pList) {
	NODE *cur = pList->head;
	tTOKEN* data;
	while (cur != NULL) {
		data = cur->dataPtr;
		printf("%s\t%d\n", data->token, data->freq);

		cur = cur->link;
	}
}

/* internal insert function
inserts data into a new node
return	1 if successful
0 if memory overflow
*/
static int _insert(LIST *pList, NODE *pPre, tTOKEN *dataInPtr) {
	NODE *node;

	node = (NODE *)calloc(sizeof(NODE));
	if (node == NULL) {
		return 0;
	}
	node->dataPtr = dataInPtr;

	node->link = pPre->link;
	pPre->link = node;
	if (node->link == NULL) {
		pList->rear = node;
	}

	pList->count++;

	return 1;
}

/* internal delete function
deletes data from a list and saves the (deleted) data to dataOut
*/
static void _delete(LIST *pList, NODE *pPre, NODE *pLoc, tTOKEN **dataOutPtr) {
	NODE *node = pLoc;

	*dataOutPtr = pLoc->dataPtr;
	pPre->link = pLoc->link;

	if (node == pList->head) {
		pList->head = node->link;
	}
	else if (node == pList->rear) {
		pList->rear = pPre;
	}

	if (node == pList->pos) {
		pList->pos = node->link;
	}

	free(node);

	pList->count--;

}

/* internal search function
searches list and passes back address of node
containing target and its logical predecessor
return	1 found
0 not found
*/
static int _search(LIST *pList, NODE **pPre, NODE **pLoc, tTOKEN *dataInPtr) {
	NODE *prev,*curNode;
	*pPre = pList->head;
	*pLoc = pList->head;
	curNode = pList->head;

        if (pList->count == 0) {
                return 0;
        }

	while (curNode != NULL) {
		tTOKEN *curData = curNode->dataPtr;
		int ret = strcmp(dataInPtr->token, curData->token);
		if (ret == 0) {
			*pLoc = curNode;
			return 1;
		}
		if (ret < 0) {
			if (*pLoc == pList->head) {
				*pPre = NULL;
			 }
			*pLoc = curNode;
			return 0;
		}

        *pPre = curNode;
        *pLoc = curNode->link;

		curNode = curNode->link;		
	}

	return 0;
}

/* Allocates dynamic memory for a token structure, initialize fields(token, freq) and returns its address to caller
return	token structure pointer
NULL if overflow
*/
tTOKEN *createToken(char *str) {
	tTOKEN *tok;

	tok = (tTOKEN *)calloc(1, sizeof(tTOKEN));
	if (tok == NULL) {
		return NULL;
	}

	tok->token = strdup(str);
	tok->freq = 1;
	
	return tok;
}

/* Deletes all data in token structure and recycles memory
return	NULL head pointer
*/
tTOKEN *destroyToken(tTOKEN *pToken) {
	free(pToken->token);
	free(pToken);
	return NULL;
}

////////////////////////////////////////////////////////////////////////////////
int main(void)
{
	LIST *list;
	char str[1024];
	tTOKEN *pToken;
	int ret;

	// creates a null list
	list = createList();
	if (!list)
	{
		printf("Cannot create list\n");
		return 100;
	}

	while (scanf("%s", str) == 1)
	{
		pToken = createToken(str);
		// insert function call
		ret = addNode(list, pToken);

		if (ret == 1) // duplicated 
			destroyToken( pToken);
	}
	// print function call
	printList(list);

	destroyList(list);

	return 0;
}
